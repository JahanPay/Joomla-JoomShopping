<script type="text/javascript">
function check_pm_jahanpay(){
    $_('payment_form').submit();
}
</script>