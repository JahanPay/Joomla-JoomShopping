﻿<?php
@session_start();
defined('_JEXEC') or die('Restricted access');

// error_reporting(1);
// ini_set("display_errors", "On"); 

if(!class_exists('nusoap_base')){
	include_once('lib/nusoap.php');
}

class pm_jahanpay extends PaymentRoot{
    
    function showPaymentForm($params, $pmconfigs){
        include(dirname(__FILE__)."/paymentform.php");
    }

	//function call in admin
	function showAdminFormParams($params){
	  $array_params = array('MerchantCode', 'muser', 'mpass', 'transaction_end_status', 'transaction_pending_status', 'transaction_failed_status');
	  foreach ($array_params as $key){
	  	if (!isset($params[$key])) $params[$key] = '';
	  } 
	  
	  $jver = new JVersion();
	  if( $jver->RELEASE[0] == 2 ){
		  $orders = &JModel::getInstance('orders', 'JshoppingModel');
	  }else{
		  $orders = JSFactory::getModel('orders', 'JshoppingModel'); //admin model
	  }	
      include(dirname(__FILE__)."/adminparamsform.php");  
	}
	
	function checkTransaction($pmconfigs, $order, $act){
	
		$orderId = (int) $_GET["orderid"];
		$api = $pmconfigs['MerchantCode'];
		$amount = $_GET['amount']/10; //Tooman
		$au=$_SESSION['au'];
		$client = new SoapClient("http://www.jpws.me/directservice?wsdl");
		$result = $client->verification($api , $amount , $au , $orderId, $_POST + $_GET );

		if( ! empty($result['result']) and $result['result'] == 1){
			$id_get = $orderId;
			$trans_id = $au;
			$mess = "پرداخت با موفقیت انجام شده است. شماره تراکنش: $id_get    شناسه پرداخت: $trans_id";
			$_SESSION['verifySaleOrderId'] = $id_get;
			$_SESSION['verifySaleReferenceId'] = $trans_id;	
			return array(1, $mess);
		}
		else{
			$mess = "خطا: " . $result['result'];
			return array(0, $mess);
		}		
		
	exit;
	

	}
	
	function showEndForm($pmconfigs, $order){
		
		$amount = round($order->order_total);
		$return = JURI::root(). "index.php?option=com_jshopping&controller=checkout&task=step7&act=return&orderid=".$order->order_id."&js_paymentclass=pm_jahanpay&amount=".$amount;

		$client = new SoapClient("http://www.jpws.me/directservice?wsdl");
		$api = $pmconfigs['MerchantCode'];
		$amount = $amount/10; //Tooman
		$callbackUrl = $return;
		$orderId = $order->order_id;
        $res = $client->requestpayment($api ,$amount ,$callbackUrl ,$orderId);	
        
        
       if( ! empty($res['result']) and $res['result'] == 1){
        $_SESSION['au']=$res['au'];
		  echo ('<div style="display:none;">'.$res['form'].'</div><script>document.forms["jahanpay"].submit();</script>');
	  }else{
		  $mess = "خطا: " . $res['result'];
			return array(0, $mess);
	  }
		
	}
    
    function getUrlParams($pmconfigs){                        
        $params = array(); 
        $params['order_id'] = JRequest::getInt("orderid");
        $params['hash'] = "";
        $params['checkHash'] = 0;
        $params['checkReturnParams'] = $pmconfigs['checkdatareturn'];
		return $params;
    }
    
}
?>