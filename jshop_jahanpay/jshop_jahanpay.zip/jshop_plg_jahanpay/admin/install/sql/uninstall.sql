SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

DELETE FROM `#__jshopping_payment_method` WHERE `payment_code` = 'jahanpay'